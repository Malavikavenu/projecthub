from django.shortcuts import render,redirect

from django.views.generic import View

from django.utils import timezone


from myapp.forms import CategoryForm,TransactionsForm,TransactionFilterForm,RegistrationForm,LoginForm

from myapp.models import Category,Transactions

from django.db.models import Sum

from django.contrib.auth import authenticate,login,logout

from django.contrib import messages

from myapp.decorators import signin_requered

from django.utils.decorators import method_decorator




@method_decorator(signin_requered,name="dispatch")
class CategoryCreateView(View):

    def get(self,request,*args,**kwargs):

        if not request.user.is_authenticated:
            messages.error(request,"invalid session")
            return redirect("signin")


      

        form_instance=CategoryForm(user=request.user)

        qs=Category.objects.filter(owner=request.user)

        return render(request,"category_add.html",{"form":form_instance,"categories":qs})
    
    def post(self,request,*args,**kwargs):

        if not request.user.is_authenticated:
            messages.error(request,"invalid session")
            return redirect("signin")



        form_instance=CategoryForm(request.POST,user=request.user,files=request.FILES)

        if form_instance.is_valid():

            form_instance.instance.owner=request.user

            form_instance.save()

            return redirect("category-add")
        else:
            return render(request,"category_add.html",{"form":form_instance})
        

        
@method_decorator(signin_requered,name="dispatch")
class CategoryUpdateView(View):
    def get(self,request,*args,**kwargs):

        
        
        id=kwargs.get("pk")
        category_object=Category.objects.get(id=id)
        form_instance=CategoryForm(instance=category_object,user=request.user)
        return render(request,"category_edit.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

       

        id=kwargs.get("pk")
        cat_obj=Category.objects.get(id=id)
        form_instance=CategoryForm(request.POST,instance=cat_obj,user=request.user)

        if form_instance.is_valid():
           
            form_instance.save()

            return redirect("category-add")
        else:
            return render(request,"category_edit.html",{"form":form_instance})
        

        

@method_decorator(signin_requered,name="dispatch")
class CategoryDeleteView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("pk")

        Category.objects.get(id=id).delete()
        return redirect("category-add")
    

    
@method_decorator(signin_requered,name="dispatch")
class TransactionsCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TransactionsForm()

        cur_month=timezone.now().month

        cur_year=timezone.now().year

        categories=Category.objects.filter(owner=request.user)

        qs=Transactions.objects.filter(created_date__month=cur_month,created_date__year=cur_year,owner=request.user)

        return render(request,"transaction_add.html",{"form":form_instance,"transactions":qs,"categories":categories})
    
    
    def post(self,request,*args,**kwargs):

        form_instance=TransactionsForm(request.POST)
        if form_instance.is_valid():

            form_instance.instance.owner=request.user

            form_instance.save()

            return redirect("trans-add")
        else:
            return render(request,"transaction_add.html",{"form":form_instance})
        

        
@method_decorator(signin_requered,name="dispatch")
class TransactionsUpdateView(View):
    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        trans_object=Transactions.objects.get(id=id)
        form_instance=TransactionsForm(instance=trans_object)

        return render(request,"transaction_edit.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get("pk")
        trans_obj=Transactions.objects.get(id=id)
        form_instance=TransactionsForm(request.POST,instance=trans_obj)

        if form_instance.is_valid():
            form_instance.save()

            return redirect("trans-add")
        else:
            return render(request,"transaction_edit.html",{"form":form_instance})
        

        

@method_decorator(signin_requered,name="dispatch")
class TransactionsDeleteView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        Transactions.objects.get(id=id).delete()
        return redirect("trans-add")
    


@method_decorator(signin_requered,name="dispatch")  
class ExpenseSummaryView(View):
    def get(self,request,*args,**kwargs):
        cur_month=timezone.now().month
        cur_year=timezone.now().year

        qs=Transactions.objects.filter(created_date__month=cur_month,
                                       created_date__year=cur_year,
                                       owner=request.user
                                       )



        total_expense=qs.values("amount").aggregate(total=Sum("amount"))#{"total":12344}

        category_summary=qs.values("category_object__name").annotate(total=Sum("amount"))

        payment_summary=qs.values("payment_method").annotate(total=Sum("amount"))


        print(payment_summary)

        data={
                "total_expense":total_expense.get("total"),
                "category_summary":category_summary,
                "payment_summary":payment_summary,
        }

        return render(request,"expense_summary.html",data)
    

    
@method_decorator(signin_requered,name="dispatch")
class TransactionSummaryView(View):
    def get(self,request,*args,**kwargs):

        form_instance=TransactionFilterForm()
        cur_month=timezone.now().month
        cur_year=timezone.now().year
       

        if "start_date" in request.GET and "end_date" in request.GET:
            st_date=request.GET.get("start_date")

            end_date=request.GET.get("end_date")
            qs=Transactions.objects.filter(
                                           created_date__range=(st_date,end_date)
            )


        else:

            qs=Transactions.objects.filter(
                                       created_date__month=cur_month,
                                       created_date__year=cur_year
                                       )
        return render(request,"transaction_summary.html",{"transaction":qs,"form":form_instance})
    
class ChartView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"chart.html")
    

class SignUpView(View):
    def get(self,request,*args,**kwargs):

        form_instance=RegistrationForm()

        return render(request,"register.html",{"form":form_instance})  
    
    def post(self,request,*args,**kwargs):

        form_instance=RegistrationForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            messages.success(request,"account created successfully")


           
            return redirect("signin")
        
        else:
            

            messages.error(request,"failed to create account")

            return render(request,"register.html",{"form":form_instance})

class SignInView(View):
    def get(self,request,*args,**kwargs):
        
        form_instance=LoginForm()

        return render(request,"login.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):
        #step1 extract username,password from LoginForm

        #step2 authenticate user with username,password
        #step3 start the session
        form_instance=LoginForm(request.POST)


        if form_instance.is_valid():

            data=form_instance.cleaned_data

            user_obj=authenticate(request,**data)

            if user_obj:

                login(request,user_obj)

                messages.success(request,"login successfully")

                return redirect("summary")


        messages.error(request,"failed to login")

        return render(request,"login.html",{"form":form_instance})
    


@method_decorator(signin_requered,name="dispatch")
class SignOutView(View):
    def get(self,request,*args,**kwargs):

        logout(request)

        return redirect("signin")







    
